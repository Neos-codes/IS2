from recomendar import recomendar_un_video
import horario
import time


def choose_from(choices, prompt_choices="Opciones: ", prompt_input="Ingrece opcion: ", prompt_fail="Opcion no es valida.", prompt_go_back="Volver atras.", go_back_option=True):
    print(prompt_choices)
    if not isinstance(choices, list):
        choices = list(choices)
    if go_back_option:
        choices = choices + [(-1, prompt_go_back)]
    valid_choices = set(range(len(choices)))
    for i, (value, label) in enumerate(choices):
        if label is None:
            label = value
        print(f"{i}.", label)
    while True:
        index = input(prompt_input).lower()
        if index.isdigit():
            index = int(index)
        if index in valid_choices:
            value, label = choices[index]
            return value
        print(prompt_fail)


def new_materia(week: horario.Week):
    while True:
        name = input("Ingrese nombre de nueva materia: ").lower()
        if name not in week.materias:
            week.add_materia(name)
            return name
        print("Materia {name} ya existe.")


def print_horario(week: horario.Week):
    print(week)


def print_materias(week: horario.Week):
    print("Materias:")
    print(' '.join(week.materias))
    print()


def add_horario_to_materia(week: horario.Week, horario=None):
    if horario is None:
        prompr_materia = "Agregar materia:"
    else:
        prompr_materia = f"Agregar a dia {horario.day.name} a las {horario.time} hrs la materia:"
    while True:
        materia = choose_from(week.choices_materia, prompt_choices=prompr_materia)
        if materia == 0:
            materia = new_materia(week)
        elif materia == -1:
            return
        if horario is None:
            add_materia_to_horario(week, materia=materia)
        else:
            week.add_materia(materia, horario)


def add_materia_to_horario(week: horario.Week, materia=None):
    if materia is None:
        prompt_dia = "Agregar a dia:"
        prompt_horario = "Agregar a horario de dia {day.name}:"
    else:
        prompt_dia = f"Agregar materia '{materia}' a dia:"
        prompt_horario = f"Agregar materia '{materia}' a horario de dia {{day.name}}:"
    while True:
        day = choose_from(week.choices_day, prompt_choices=prompt_dia)
        if day == -1:
            break
        while True:
            horario = choose_from(day.choices_horario, prompt_choices=prompt_horario.format(day=day))
            if horario == -1:
                break
            if materia is None:
                add_horario_to_materia(week, horario=horario)
            else:
                week.add_materia(materia, horario)


def get_video(week: horario.Week):
    if not week:
        video = recomendar_un_video(new_materia(week))
    datetime = time.struct_time(time.localtime())
    video = week.get_video_recomendation_for_time(datetime.tm_wday, datetime.tm_hour, datetime.tm_min)
    while video is None:
        choice = choose_from([(0, "Hora mas proxima."), (1, "Hora especifica."), (2, "Materia especifica.")],
                         prompt_choices="No tiene ninguna materia registrada a esta hora. Desea una recomendacion para: ")
        repetidos = list() #lista que contiene el nombre de los videos que ya han sido buscados
        mantener = True
        #este while sirve para repetir la busqueda si se desea refrescar la lista de videos
        videos = list() #lista donde se almacenan los videos encontrados
        while mantener:  
            if choice == -1:
                return
            elif choice == 0:
                horario = next(filter(None, week.week_iterator(day=datetime.tm_wday, horario=datetime.tm_hour)))
                video = week.get_video_recomendation_for_time(horario.day, horario, 0)
                for item in video:
                    #se revisan todos los videos obtenidos y se obtienen aquellos que no se encuantren en la lista de repetidos
                    if repetidos.count(item['id']['videoId']) <= 0:
                        videos.append(item)
                        repetidos.append(item['id']['videoId'])
            elif choice == 1:
                while video is None:
                    day = choose_from(filter(lambda x: x[0], week.choices_day), prompt_choices="Dia:")
                    if day == -1:
                        break
                    while video is None:
                        horario = choose_from(filter(lambda x: x[0], day.choices_horario), prompt_choices="Hora:")
                        if horario == -1:
                            break
                        video = week.get_video_recomendation_for_time(day, horario, 0)
                        for item in video:
                            #se revisan todos los videos obtenidos y se obtienen aquellos que no se encuantren en la lista de repetidos
                            if repetidos.count(item['id']['videoId']) <= 0:
                                videos.append(item)
                                repetidos.append(item['id']['videoId'])
            elif choice == 2:
                materia = choose_from(week.choices_materia)
                if materia == -1:
                    continue
                elif materia == 0:
                    materia = new_materia(week)
                video = recomendar_un_video(materia)     
            
            elejir = True
            listaTitulos = list() #arreglo donde se guardan los titulos de los videos obtenidos
            index = 0
            #este while sirve para mantener la estructura del menu y volver a la lista de videos buscados despues de ver informacion de otro
            while(elejir):
                
                #se crea una lista de tuplas con los videos obtenidos y un indice, para usar la funcion choose_from
                for item in videos:
                    tupla = (index, item['snippet']['title'])
                    listaTitulos.append(tupla)
                    index += 1
                        
                #si la cantidad de videos obtenidos es menor a 3, se vuelven a buscar videos
                if len(listaTitulos) < 3:
                    break
                    
                #se obtiene el numero actual de videos
                tam = len(listaTitulos)
                
                #se agrega a la lista, la opcion de refrescar los videos
                listaTitulos.append((tam,"refrescar lista de videos"))
                
                #se despliegan las opciones y se optiene la opcion elejida por el usuario
                title = choose_from(listaTitulos, prompt_choices="elija el video")
                
                #si se elije la opcion volver, se termina el bucle
                if title == -1:
                    mantener = False
                    break
                
                #si se elige refrescar la lista, se borran los videos obtenidos y se v
                if title == tam:
                    index = 0
                    listaTitulos.clear()
                    videos.clear()
                    break
                
                elejido = None
                #se revisa si la opcion elejida se corresponde con uno de los videos
                for item in videos:
                    if item['snippet']['title'] == listaTitulos[title][1]:
                        elejido = item
                        break
                
                #se muestran los datos del video optenido
                print()
                print("Materia:", elejido["materia"])
                print(elejido['snippet']['title'])
                print("Canal:", elejido['snippet']['channelTitle'])
                print(f"Duracion[mm:ss]: {elejido['duration']: >2.0f}:{60 * (elejido['duration'] % 1):0>2.0f}")
                print(elejido['snippet']['description'])
                print(f"Url: https://www.youtube.com/watch?v={elejido['id']['videoId']}")
                print()
                
                #se optienen otras opciones por si se quiere ver el video
                choice = choose_from([(0, "si"), (1, "no")],prompt_choices="¿desea ver el video?")
                
                #se vuelve a la lista de titulos
                if choice == -1:
                    continue
                #se ve el video
                elif choice == 0:
                    print("video visto")
                    #poner funcion de agregar al historial
                    
                    #se optienen otras opciones por si se quiere agregar el video a favoritos
                    choice2 = choose_from([(0, "si"), (1, "no")],prompt_choices="¿desea agregar el video a favoritos?")
                    
                    #se agrega el video favoritos
                    if choice2 == 0:
                        print("video agregado a favoritos")
                        #poner funcion de agregar a favoritos
                
                #se borra la lista de titulos para que no se repitan
                listaTitulos.clear()
                


MAIN_MENU = {"choices": [(print_horario, "Ver mi horario."),
                         (print_materias, "Ver mis materias."),
                         (add_horario_to_materia, "Añadir horas a materias."),
                         (add_materia_to_horario, "Añadir materias a horas."),
                         (get_video, "Recibir recomendacion de video.")],
             "prompt_choices": "¿Que desea hacer?",
             "prompt_input": "(Ingrese numero):",
             "prompt_go_back": "Salir"}
