# IS2
Semestral Project from "Ingeniería de Software 2" 2021-1

## How to run
### Linux
python3 main.py
### Windows (using bash)
python main.py
